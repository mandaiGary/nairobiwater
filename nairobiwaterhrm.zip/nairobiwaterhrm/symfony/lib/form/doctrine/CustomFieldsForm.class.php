<?php

/**
 * CustomFields form.
 *
 * @package    form
 * @subpackage CustomFields
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class CustomFieldsForm extends BaseCustomFieldsForm
{
  public function configure()
  {
  }
}