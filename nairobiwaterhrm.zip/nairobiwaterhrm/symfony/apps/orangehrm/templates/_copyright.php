<?php 
$version = '3.3.3';
$prodName = 'NairobiWater';
$copyrightYear = date('Y');

?>
<?php echo $prodName . ' ' . $version;?><br/>
&copy; 2005 - <?php echo $copyrightYear;?> <a href="http://www.narobiwater.com" target="_blank">NairobiWater, Compy</a>. All rights reserved.
